define(['util'], function (util) {

  function formate(data) {
    var str = '';
    for (var key in data) {
      str += key + '=' + data[key] + '&'
    };
    // name=3&age=1
    return str.replace(/&$/, '');
  }

  function Ajax(opt) {
    return new Promise((resolve, reject) => {
      var xhr = new XMLHttpRequest();
      xhr.onload = () => {
        if (xhr.status == 200) {
          if (xhr.response) {
            resolve(JSON.parse(xhr.response))
            // this.opt.success(JSON.parse(xhr.response))
          }
        }
      };
      //向服务器发送的数据
      var data = typeof opt.data === 'string' ? opt.data : formate(opt.data);
      //url
      var url = opt.type === 'get' && data != "" ? opt.url + '?' + data : opt.url;
      xhr.open(opt.type, url, opt.async);
      xhr.send(opt.type === 'get' ? null : data);
    })
  }
  return Ajax
})
