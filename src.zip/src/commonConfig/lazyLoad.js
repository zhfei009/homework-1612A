define(function () {
    function Lazyload(ops) {
        var elimg = document.querySelector(ops.el)
        this.el = Array.from(document.querySelectorAll(ops.el));
        this.ops = ops;
        this.load();
    };
    Lazyload.prototype = {
        load () {
            //图片距可视区域顶部的距离小于可视区域的高度;
            var clientHeight = window.innerHeight;

            this.el.forEach( (el) => {
                var offset = el.getBoundingClientRect(); // 当前的距离
                //  console.log(this.el.children[0], 'this.el')
                if (offset.top < clientHeight) {
                    var src = el.children[0].getAttribute(this.ops.attr); // data-src
                    el.children[0].src = src;
                }
            })
        }
    }
    return Lazyload;

    //   (function() {
    //       this.load = function() {
    //           //实现图片加载
    //           //图片距可视区域顶部的距离小于可视区域的高度
    //           var clientHeight = window.innerHeight;
    //           var that = this;

    //           this.el.forEach(function(el) {
    //               console.log(el.children[0], 'el')
    //               var offset = el.getBoundingClientRect();

    //               if (offset.top < clientHeight) {
    //                   var src = el.children[0].getAttribute(that.ops.attr); // data-src
    //                   el.children[0].src = src;
    //               }
    //           })
    //       }
    //   }).call(Lazyload.prototype);
    //   return Lazyload;

});