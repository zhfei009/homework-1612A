define([], function(require, factory) {
  var init = {
    //
    formate:function(url) {
      // console.log(url, 'util--->')
      return JSON.parse('{"' + url.replace(/&/g, '","').replace(/=/g, '":"') + '"}');
    },

  }
  return init;
});