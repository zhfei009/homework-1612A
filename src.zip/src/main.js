// 头部
require.config({ //
  baseUrl: '../components', // 如果不设置这个属性,就会根据data-main去查找路径
  paths: {
    "jquery": "../libs/jquery.min",
    'css': "../libs/css.min",    // 引入css插件
    'Mock': "../libs/mock-min",
    'jqueryValdation': '../libs/jquery-validation',
    'Swiper': '../libs/swiper.min',    // 引入swiper
    'Ajax': '../commonConfig/ajax',
    'text': '../libs/text', // 解析html
    'login': 'login',  // 登陆模块
    'homepage': 'homepage', // 首页模块
    'getMockData': '../commonConfig/getMockData',
    'util': '../commonConfig/util',
    'register': 'register',
    'lazyLoad': '../commonConfig/lazyLoad',
    'myajax': '../commonConfig/myajax'
  },
  shim: { // 加载项目依赖的时候使用的配置项
    "jquery": {
      deps: [],
      exports: "jquery"
    },
    'jqueryValdation': {
      deps: ['jquery'],      // 当前js依赖的
      exports: 'jqueryValdation'
    },
    'Ajax': {
      deps: [],      // 当前js依赖的
      exports: 'Ajax' //
    },
    'text': {
      deps: [],
      exports: 'text'
    },
    Swiper: {
      deps: ['css!../libs/swiper.min.css'],
      exports: 'Swiper'
    },
    admin: {
    	'deps': ['jquery', 'css!../css/admin.css']
    },
    homepage: {
      'deps': ['jquery','css!../css/homepage.css','css!../libs/swiper.min.css','css!../fonts/iconfont.css']
    }
  }
});

/*
main.js 中只写config
home.html  home.js
paths:
shim:

当前文件下.通过require引入需要的js模块文件;
* */
