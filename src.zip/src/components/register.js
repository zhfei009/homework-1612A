define([
  'getMockData',
  'Ajax'
], function (getMockData, Ajax) {

  var registerBtn = document.getElementById('registerBtn');
  var user = document.getElementById('user');
  var pwd = document.getElementById('pwd');
  // var obj = {
  //   name: user.value,
  //   pwd: pwd.value
  // }
  // console.log(...obj)

  registerBtn.onclick = function () {
    new Ajax({
      url: '/api/register',
      dataType: 'json',
      type: 'post',
      data: {
        name: user.value,
        pwd: pwd.value
      },
      success: function (res) {
        // console.log(res)
      }
    })

  }


  // btn.onclick = function() {
  //   new Ajax({
  //     url: '/api/item',
  //     type: 'post',
  //     dataType: 'json',
  //     success:function(res) { // 接收数据
  //        console.log(res, 'res---->')
  //     }
  //   })
  //   new Ajax({
  //     url: '/api/item_list',
  //     type: 'post',
  //     data: {
  //       name: 2,
  //       age: 34
  //     },
  //     success:function(res) { // mock后端处理后返回的数据
  //        console.log(res, 'res---->')
  //     }
  //   })
  // }


});