define([
  'Swiper',
  'jquery',
  'Ajax',
  'text!../template/header.html',
  'getMockData',
  'util',
  'lazyLoad',
  'myajax'
], function (Swiper, $, Ajax, header, getMockData, util, lazyLoad, myajax) {


    // 复用头部的html结构 顶部login区域
    var headerContainer = document.querySelector('.home-header-wrap');
    //  console.log(header, )
    headerContainer.innerHTML = header;
    // 登陆状态的显示与隐藏；
    var loginBtn = document.querySelector('.icon-gerenzhongxin');
    var showHeaderLogin = document.querySelector('.header-login-show');

  // 判断登陆状态，如果登陆的话，就是登陆显示框中，划过的时候 显示登陆， 反之亦然；
  function isLogin() {
    var stroge = window.localStorage;
    console.log(stroge.length, 'leng-stoge')
    if (stroge.getItem('name')) {
      // 若果有名字，就显示在登陆窗口中\
      var name = stroge.getItem('name');
      var str = `<p>账号：<span class="login-user">${name}</span> <button>退出登陆</button></p> `;
      showHeaderLogin.innerHTML = str;
    } else {
      //  alert('没有登陆名字')
    }
  }

  // show-header-login
  loginBtn.onmouseover = function () {
    showHeaderLogin.classList.add('show-header-login')
    isLogin()
  }
  loginBtn.onmouseout = function () {
    // showHeaderLogin.classList.remove('show-header-login')
  }

  var loginHeaderBtn = document.getElementById('loginHeaderBtn');
  loginHeaderBtn.onclick = function() {
    window.location.href = 'login.html';
  }






  // console.log(myajax)
  // myajax({
  //   url:'http://localhost:3000/msg',
  //   type: 'get',
  // }).then(res => {
  //   console.log(res, 'res--->')
  // })

  // new Ajax({
  //   url: 'http://localhost:3000/msg',
  //   success:function(res){
  //     console.log(res, 'res--->')
  //   }
  // })

  //  $.get('http://localhost:3000/msg',function(res) {
  //    console.log(res)
  //  })


  // new Ajax('get', '../mock/data.json', function(res){
  //  console.log(res, 'ajax-res')
  // })
  //     console.log(headerContainer, 'headerContainer')
  // // setTimeout(function() {
  //   var iconBtn = document.querySelector('.icon-gerenzhongxin');
  //   var loginShow = document.querySelector('.header-login-show')
  //   iconBtn.onmouseover = function() {
  //     loginShow.style.display = 'block';
  //   }
  //   iconBtn.onmouseout = function() {
  //     loginShow.style.display = 'none';
  //   }
  // // })


  // console.log(loginShow, 'loginShow')
  // loginShow.onclick = function() {
  //   console.log(1)
  // }


  Ajax({
    url: '/api/item',
    type: 'post',
  }).then(res => {
    console.log(res)
  })

  // 吸顶效果
  var nav = document.querySelector('.home-header-wrap');
  var tops = nav.offsetTop;
  window.addEventListener('scroll', function () {
    var scrollTops = document.documentElement.scrollTop || document.body.scrollTop;
    if (scrollTops > tops) {
      nav.classList.add('fixed');
    } else {
      nav.classList.remove('fixed');
    }
  });

  // 图片懒加载效果
  window.addEventListener('scroll', function () {
    new lazyLoad({
      el: ".home-goods-new-item-two",
      attr: "data-src"
    })
  });




  new Ajax({
    url: '/api/list',
    dataType: 'json',
    type: 'post',
    success: function (res) {
      //  console.log(res, 'homepage--->')
    }
  })

  new Ajax({
    url: '/api/login',
    dataType: 'json',
    type: 'post',
    data: {
      name: 1,
      pwd: 345
    },
    success: function (res) {
      //  console.log(res, 'homepageLOgin--->')

    }
  })

  new Ajax({
    url: '../mock/home.json',
    type: 'get',
    success: function (res) {
      //  console.log(res, 'res---mock')
    }
  })

  // getMOckdatajs定义接口的,
  // 主入口文件main.js中进行注册
  // 在当前需要请求数据的模块中引入getmockdata,
  // ajax请求

  // Ajax({
  //   url: '../mock/data.json',
  //   dataType: 'json',
  //   type: 'post',
  //   success:function(res) {
  //     console.log(res, 'ajax--->')
  //   }
  // })

  // new Ajax({
  //   url: '/api/searchList',
  //   type: 'get',
  //   success: function(res) {
  //     console.log(res, 'res-=-->')
  //   }
  // })


  new Swiper('.swiper-container', {
    pagination: {
      el: '.swiper-pagination',
      // type: 'fraction', // 数字
      // type: 'progressbar', // 数字
      // type: 'custom',
      bulletElement: 'li',
    },
  })
});
//