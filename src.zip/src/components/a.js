define([
  'require',
  'dependency'
], function(require, factory) {
  'use strict';

});