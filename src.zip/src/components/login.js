define([
  'Ajax',
  'getMockData',
  'util'
], function (Ajax, getMockData, util) {
  var loginBtn = document.getElementById('loginBtn');
  var user = document.getElementById('user');
  var pwd = document.querySelector('#pwd');

  loginBtn.onclick = function () {
    loginAjax()
  }

  // 登陆请求ajax
  function loginAjax() {
    new Ajax({
      url: '/api/login',
      type: 'post',
      data: {
        name: user.value,
        pwd: pwd.value
      }
    })
    .then(res => {
      console.log(res, 'res---->')
      if (res.code == 0) {
        console.log('rescode-0')
        strogeLogin(user.value)
        alert('登陆成功')
        window.location.href = 'homepage.html'
      } else {
        alert('登陆失败')
        window.location.href = 'register.html'
      }
    })
  }

  function strogeLogin(name) {
    var stroge = window.localStorage;
    stroge.setItem('name', name)
  }

  // login.js登陆模块中 ajax请求 post（给后端发送数据--账号--密码）；
  // 还需要引入mock模拟接口的文件
  // 处理前端发来的数据
  // util.js工具函数模块;  格式化数据函数


});